# 🍫 Chocolate Sales Analysis – Power BI Report

Interactive Power BI dashboard analyzing **chocolate product sales** across multiple countries from **January 2025 to September 2026**.

![Power BI Report](images/powerbi-report-desktop.jpg)

## 📊 Report Overview

| Metric | Value |
|--------|-------|
| **Total Sales Amount** | $21.53 Million |
| **Total Boxes Sold** | ~2 Million |
| **Date Range** | 02 Jan 2025 – 30 Apr 2026 (filtered view) |
| **Records** | 4,998 transactions |

### Key Visuals

1. **How much money we make every month?**  
   Area chart showing monthly revenue trends (Jan 2025 – Mar 2026).

2. **Sum of Amount by Product**  
   Horizontal bar chart ranking products by revenue.  
   Top performers: *Orange Choco*, *99% Dark & Pure*, *Drinking Coco*, *Peanut Butter Cubes*.

3. **Sum of Amount by Country**  
   Donut chart showing revenue share:  
   - UK – 26.18%  
   - USA – 22.93%  
   - India – 16.63%  
   - Canada, Australia, New Zealand

4. **Sales Person Performance**  
   Table of top sales representatives by total amount (e.g. Brien Boise leading at ~1.67M).

---

## 📁 Project Structure

```
chocolate-sales-powerbi/
├── data/
│   ├── chocolate_sales_data.csv          # Clean CSV version
│   └── sample-chocolate-sales-data-1.xlsx # Original Excel source
├── images/
│   ├── powerbi-report-desktop.jpg
│   └── powerbi-report-web.jpg
├── docs/
│   └── (optional future documentation)
└── README.md
```

---

## 🗂 Data Dictionary

| Column         | Description                          | Type     |
|----------------|--------------------------------------|----------|
| Sales Person   | Name of the sales representative     | Text     |
| Product        | Chocolate product name                   | Text     |
| Country        | Sales country                        | Text     |
| Date           | Order date                           | Date     |
| Amount         | Sales amount (currency)              | Decimal  |
| Boxes          | Number of boxes sold                 | Integer  |
| Order Status   | Delivered / Shipped / Cancelled / Placed | Text |

**Order Status distribution (full dataset):**
- Delivered: 4,138
- Shipped: 433
- Cancelled: 227
- Placed: 200

---

## 🚀 How to Recreate the Report in Power BI

1. Open **Power BI Desktop**.
2. **Get Data** → Excel or CSV → select `data/chocolate_sales_data.csv` (or the `.xlsx`).
3. Load the data.
4. Create the following visuals:
   - **Card**: Sum of Amount → format as $21.53M
   - **Card**: Sum of Boxes → format as 2M
   - **Area Chart**: Axis = Date (Month), Values = Sum of Amount
   - **Bar Chart**: Axis = Product, Values = Sum of Amount (sorted descending)
   - **Donut Chart**: Legend = Country, Values = Sum of Amount
   - **Table**: Sales Person + Sum of Amount
5. Add a **Date slicer** (between 02/01/2025 and 30/04/2026).
6. Publish to Power BI Service if desired.

---

## 📈 Sample Insights

- **Brien Boise** is consistently one of the top performers.
- **Orange Choco** and dark chocolate variants generate the highest revenue.
- UK and USA dominate the market share.
- Clear seasonal peaks visible in the monthly revenue chart (mid-year and early 2026).

---

## 🛠 Tools Used

- **Microsoft Power BI Desktop / Service**
- **Excel / CSV** as data source
- Data period: Jan 2025 – Sep 2026

---

## 📌 License

This project is for demonstration and portfolio purposes.  
Feel free to use the data and report structure in your own learning projects.

---

**Created for GitHub portfolio** · Chocolate Sales Analytics Dashboard
